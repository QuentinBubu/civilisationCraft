<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'MTXSERV' ?></title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    <header class="top_bar">
        <div class="img_top_bar">
            <a href="<?= $router->generate('home') ?>">
                <img
                    src="./assets/picture/logo/logo.ico"
                    alt="Logo du serveur"
                    id="logo_top_bar"
                />
            </a>
        </div>
        <div class="others_top_bar">
            <span>
                <a href="<?= $router->generate('playerList') ?>">Liste des joueurs</a>
            </span>
            <span>
                <a href="<?= $router->generate('forum') ?>">Forum</a>
            </span>
        </div>
        <div class="connexion_button">
            <?php
            if (!isset($_SESSION['id'])) { ?>
                <p>
                    <a href="/players/connexion.php">Se connecter</a>
                    <a href="/players/inscription.php">S'inscrire</a>
                </p>
            <?php
            } else {
                $requete = $db->prepare("SELECT image_profil FROM users WHERE name_user = :name_user");
                $requete->execute([
                    "name_user" => $_SESSION['id']
                ]);
                $results = $requete->fetch();
            ?>
                <div class="profil_logo_div">
                    <img src="<?= $results['image_profil']; ?>" alt="Image de profil" id="profil_top_bar" />
                    <script>
                        var hauteur = document.getElementById("profil_top_bar").offsetHeight;
                        document.getElementById("profil_top_bar").style.width = hauteur + "px";
                    </script>
                    <div>
                        <a href="/players/cpannel.php">Paramètres</a>
                        <hr />
                        <a href="/players/deconnexion.php">Déconnexion</a>
                        <hr />
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </header>

    <?= $main ?>

    <footer class="bottom_bar">
        <img src="/admin/ressources/images/logo/logo.ico" alt="Logo du serveur"/>
        <span>
            Tous droits réservés à MTXSERV | 
            &copy; 2015-2020 | 
            <a href="/admin/ressources/code/mentions-legals.php">
                Mentions légales
            </a>
        </span>
    </footer>
</body>
</html>