<?php

$routeur->map('GET', '/', 'home', 'home');
$routeur->map('GET', '/home', 'home');
$routeur->map('GET', '/index', 'home');
$routeur->map('GET', '/login', 'login');
$routeur->map('POST', '/login-back', '../App/php/LoginSignup/login', 'login-back');
$routeur->map('POST', '/signup-back', '../App/php/LoginSignup/signup', 'signup-back');

$results = $routeur->match();