<?php

$routeur = new AltoRouter();

require '/App/roads.php';

if ($results !== null) {
    if (is_callable($results['target'])){
        call_user_func_array($results['target'], $results['params']);
    } else {
        ob_start();
        require "/App/view/templates/{$results['target']}.php";
        $main = ob_get_clean();
        require '/App/view/layout.php';
    }
} else {
    require './assets/error/404.html';
}