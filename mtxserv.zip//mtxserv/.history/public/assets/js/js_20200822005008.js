let hauteur = document.getElementById("profil_top_bar").offsetHeight;
document.getElementById("profil_top_bar").style.width = hauteur + "px";