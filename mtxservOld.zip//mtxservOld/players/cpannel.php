<?php
session_start();
ini_set('display_errors', 'on');
error_reporting(E_ALL);
include "../admin/ressources/database/connexion_db.php";
include "../admin/ressources/code/functions.php";

if (isset($_GET['erreur'])) {
    $erreurV = $_GET['erreur'];
    if ($erreurV == "mdp") {
        $erreur = "Les mots de passes ne correspondent pas!";
    } elseif ($erreurV == "mail") {
        $erreur = "L'e-mail saisis n'est pas valide!";
    } elseif ($erreurV == "mailex") {
        $erreur = "L'e-mail saisis est déjà répertoriée!";
    } elseif ($erreurV == "taille_mdp") {
        $erreur = "Saisissez un mot de passe comportant entre 10 et 30 caractères!";
    } elseif ($erreurV == "old_pswd") {
        $erreur = "Votre ancien mot de passe est incorrect";
    } elseif ($erreurV == "mdp_verify") {
        $erreur = "Le mot de passe saisis est incorect";
    }
    $erreurV = "";
?>
    <script type="text/javascript">
        if (confirm("Erreur: <?php echo $erreur; ?>")) {
            document.location.href = "cpannel.php";
        } else {
            document.location.href = "cpannel.php";
        }
    </script>
    <?php
}

if (isset($_POST['older_password'])) {
    $mdp = $_POST['new_password'];
    $mdp2 = $_POST['new_password_confirm'];
    if (update_account("password", $db, $_POST['older_password'], $mdp, $mdp2, 0, $_SESSION['id']) == "ok") {
        $requete = $db->prepare("UPDATE users SET pswd = :pswd WHERE name_user = :id");
        $requete->execute([
            "pswd" => password_hash($mdp, PASSWORD_ARGON2I),
            "id" => $_SESSION['id']
        ]);
    ?>
        <script type="text/javascript">
            if (confirm("Votre mot de passe a bien été modifié!")) {
                document.location.href = "cpannel.php";
            } else {
                document.location.href = "cpannel.php";
            }
        </script>
    <?php
    }
}

if (isset($_POST['mail'])) {
    $mdp = $_POST['password'];
    $mail = $_POST['mail'];
    $token = "M" . sha1(session_id() . microtime());
    if (update_account("mail", $db, 0, $mdp, 0, $mail, $_SESSION['id']) == "ok") {
        $requete = $db->prepare("UPDATE users SET new_mail = :mail, new_token_mail = :token WHERE name_user = :id");
        $requete->execute([
            "mail" => $mail,
            "token" => $token,
            "id" => $_SESSION['id']
        ]);
    ?>
        <script type="text/javascript">
            if (confirm("Votre mail été modifié, vous allez recevoir un mail de confirmation!")) {
                document.location.href = "cpannel.php";
            } else {
                document.location.href = "cpannel.php";
            }
        </script>
    <?php
    }
}

if (isset($_POST['birthday'])) {
    $birthday = $_POST['birthday'];
    $requete = $db->prepare("UPDATE users SET birthday = :birthday WHERE name_user = :id");
    $requete->execute([
        "birthday" => $_POST['birthday'],
        "id" => $_SESSION['id']
    ]);
    ?>
    <script type="text/javascript">
        if (confirm("Votre date d'anniversaire a bien été modifiée!")) {
            document.location.href = "cpannel.php";
        } else {
            document.location.href = "cpannel.php";
        }
    </script>
<?php
}
if (isset($_POST['newsletter_submit'])) {
    if ($_POST['newsletter'] != "on") {
        $newsletter = "0";
    } else {
        $newsletter = "1";
    }
    $requete = $db->prepare("UPDATE users SET newsletter = :newsletter WHERE name_user = :id");
    $requete->execute([
        "newsletter" => $newsletter,
        "id" => $_SESSION['id']
    ]);
?>
    <script type="text/javascript">
        if (confirm("Votre abonnement a bien été modifié!")) {
            document.location.href = "cpannel.php";
        } else {
            document.location.href = "cpannel.php";
        }
    </script>
<?php
}

if(isset($_FILES['image'])){
    $return = upload_image("D:/wamp/www/mtxserv/players/profil_image/", $db, ""); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if ($return[0] == "I"){

        $requete = $db->prepare("UPDATE users SET image_profil = :link WHERE name_user = :id");
        $requete->execute([
            "link" => "/players/profil_image/" . $return,
            "id" => $_SESSION['id']
        ]);
        ?>
    <script type="text/javascript">
        if (confirm("Changement effectuer avec succès!")) {document.location.href="cpannel.php"}else{document.location.href="cpannel.php"}
    </script>
        <?php
    }else{
        ?>
    <script type="text/javascript">
        if (confirm("<?php echo $return; ?>")) {document.location.href="cpannel.php"}else{document.location.href="cpannel.php"}
    </script>
        <?php
    }
}

if (isset($_GET['del']) && $_GET['del'] == "del") {
?>
    <script type="text/javascript">
        if (confirm("Etes vous sur de vouloir supprimer votre compte?")) {
            if (confirm("Etes vous VRAIMENT sur de vouloir supprimer votre compte?")) {
                if (confirm("ATTENTION, cette action est irréversible!")) {
                    document.location.href ="/players/delet_account.php";
                } else {
                    document.location.href = "cpannel.php";
                }
            } else {
                document.location.href = "cpannel.php";
            }
        } else {
            document.location.href = "cpannel.php";
        }
    </script>
<?php
}


$requete = $db->query("SELECT name_site, description_site FROM configuration_site");
$results = $requete->fetch();
?>

<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <meta name="description" content="<?php echo $results['description_site']; ?>" />
    <link rel="shortcut icon" href="../admin/ressources/images/logo/logo.ico" />
    <link rel="stylesheet" href="../admin/ressources/style/style.css" type="text/css" />
    <title>Paramètres - <?php echo $results['name_site']; ?></title>
</head>

<body id="body_inscription">
    <?php include "/wamp/www/mtxserv/admin/ressources/code/top_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>
    <?php
    $requete = $db->prepare("SELECT token FROM users WHERE name_user = :id");
    $requete->execute([
        "id" => $_SESSION['id']
    ]);
    $results = $requete->fetch();
    if ($results['token'] != "ok") { ?> <script>
            if (confirm("Vous devez d'abord valider votre compte")) {
                document.location.href = "../index.php";
            } else {
                document.location.href = "../index.php";
            }
        </script>
    <?php
    }
    if (isset($_SESSION['account']) && $_SESSION['account'] == "Administrateur") {
    ?>
        <a href="/admin/cpannel_admin.php" style="text-decoration: none;">
            <div id="cpannel_admin_acces">
                Accéder au cpannel d'administrateur
            </div>
        </a>
    <?php
    }
    ?>

    <div class="modification_mdp">
        <form action="" method="POST">
            <input type="password" name="older_password" placeholder="Votre ancien mot de passe ici" required />
            <input type="password" name="new_password" placeholder="Votre nouveau mot de passe ici" required />
            <input type="password" name="new_password_confirm" placeholder="Confirmez votre mot de passe" required />
            <input type="submit" value="Enregistrer" />
        </form>
    </div>
    <div class="modification_mail">
        <form action="" method="POST">
            <input type="email" name="mail" placeholder="Votre nouveau mail ici" required />
            <input type="password" name="password" placeholder="Votre mot de passe ici" required />
            <input type="submit" value="Enregistrer" />
        </form>
    </div>
    <div class="modification_birthday">
        <form action="" method="POST">
            <label for="birthday">Votre date d'anniversaire:</label>
            <?php
            $requete = $db->prepare("SELECT birthday FROM users WHERE name_user = :id");
            $requete->execute([
                "id" => $_SESSION['id']
            ]);
            $results = $requete->fetch();
            ?>
            <input type="date" id="birthday" name="birthday" value="<?php echo $results['birthday']; ?>" required />
            <input type="submit" value="Enregistrer" />
        </form>
    </div>
    <div class="modification_newsletter">
        <form action="" method="POST">
            <label for="newsletter">Votre abonnement à la newsletter:</label>
            <?php
            $requete = $db->prepare("SELECT newsletter FROM users WHERE name_user = :id");
            $requete->execute([
                "id" => $_SESSION['id']
            ]);
            $results = $requete->fetch();
            ?>
            <input type="checkbox" id="newsletter" name="newsletter" <?php if ($results['newsletter'] == "1") {
                                                                            echo "checked";
                                                                        } ?> />
            <input type="submit" value="Enregistrer" name="newsletter_submit" />
        </form>
    </div>
    <div class="modification_photo_profil">
        <form action="" method="POST" enctype="multipart/form-data">
            <label>Modifier votre photo de profil</label>
            <input type="file" accept="image/*" name="image"/>
            <label>(Image carré de préférence)</label>
            <input type="submit" value="Enregistrer" />
        </form>
    </div>
    <div id="bottom_profil">
        <?php
        $requete = $db->prepare("SELECT * FROM users WHERE name_user = :id");
        $requete->execute([
            "id" => $_SESSION['id']
        ]);
        $results = $requete->fetch();
        $requete2 = $db->query("SELECT nombre_avertissement FROM configuration_site WHERE 1");
        $results2 = $requete2->fetch();
        ?>
        <span>Votre nom: <?php echo $results['name_user']; ?></span>
        <span>Votre rôle: <?php echo $results['account_type']; ?></span>
        <span>Votre nombre d'avertissement: <?php echo $results['avertissements'] . "/" . $results2['nombre_avertissement']; ?></span>
        <span><a href="cpannel.php?del=del">Supprimer le compte</a></span>
    </div>

    <?php include "/wamp/www/mtxserv/admin/ressources/code/bottom_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>
</body>

</html>