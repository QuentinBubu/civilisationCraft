<?php
$dossier = "D:/wamp/www/mtxserv/players/forum/images/"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ini_set('upload_max_filesize', '11M');
ini_set('post_max_size', '11M');
$fichier = basename($_FILES['upload']['name']);
$taille_maxi = 100000000;
$taille = filesize($_FILES['upload']['tmp_name']);
$extensions = array('.png', '.gif', '.jpg', '.jpeg', '.ico');
$extension = strtolower(strrchr($_FILES['upload']['name'], '.'));
//Début des vérifications de sécurité...
if (!in_array($extension, $extensions)) //Si l'extension n'est pas dans le tableau
{
    $erreur = 'Erreur: Vous pouvez uploader un fichier de type png, gif, jpg, jpeg, ico';
} elseif ($taille > $taille_maxi) {
    $erreur = 'Erreur: Le fichier est trop volumineux...';
} else {
    $fichier = "IMG" . sha1(session_id() . microtime()) . $extension;
    if (move_uploaded_file($_FILES['upload']['tmp_name'], $dossier . $fichier)) //Si la fonction renvoie TRUE, c'est que ça a fonctionné...
    {
        $erreur = "Ok";
    } else //Sinon (la fonction renvoie FALSE).
    {
        $erreur = "Erreur: Echec lors de l'upload";
    }
}




$url = "/players/forum/images/" . $fichier;
$callback = $_GET['CKEditorFuncNum']; // Facultatif: nom d'instance (peut être utilisé pour charger un fichier de configuration spécifique ou autre). 
$msg = $erreur;
$output = '<html><body><script type="text/javascript">window.parent.CKEDITOR.tools.callFunction(' . $callback . ', "' . $url . '","' . $msg . '");</script></body></html>';
echo $output;