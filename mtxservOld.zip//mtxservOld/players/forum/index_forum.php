<?php
session_start();
include "/wamp/www/mtxserv/admin/ressources/database/connexion_db.php";
$requete = $db->query("SELECT name_site, description_site FROM configuration_site");
$results = $requete->fetch();
?>
<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <meta name="description" content="<?php echo $results['description_site']; ?>" />
    <link rel="shortcut icon" href="/admin/ressources/images/logo/logo.ico" />
    <link rel="stylesheet" href="/admin/ressources/style/style.css" type="text/css" />
    <title>Forum - <?php echo $results['name_site']; ?></title>
</head>

<body id="body_inscription">
    <?php include "/wamp/www/mtxserv/admin/ressources/code/top_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>

    <table id="table_forum">
        <thead>
            <th>Forum membres:</th>
            <th>Formun administration:</th>
        </thead>
        <tbody>
            <tr>
                <td class="td_forum_list">
                    <?php
                    $requete = $db->query("SELECT * FROM forum_list WHERE categorie = 'membres'");
                    while ($results = $requete->fetch()) {
                    ?>
                        <li><a href="affichage_post.php?topic=<?php echo $results['id'] ?>"><?php if($results['ecriture'] == 0){echo '[FERME] ';} echo $results['nom'] . " Par: " . $results['createur'] .  " Le " . substr($results['parution'], 0, 10) ?></a></li>
                    <?php
                    }
                    ?>
                </td>
                <td class="td_forum_list">
                    <?php
                    $requete = $db->query("SELECT * FROM forum_list WHERE categorie = 'administration'");
                    while ($results = $requete->fetch()) {
                    ?>
                        <li><a href="affichage_post.php?topic=<?php echo $results['id'] ?>"><?php if($results['ecriture'] == 0){echo '[FERME] ';} echo $results['nom'] . " Par: " . $results['createur'] .  " Le " . substr($results['parution'], 0, 10) ?></a></li>
                    <?php
                    }
                    ?>
                </td>
            </tr>
        </tbody>
    </table>


    <?php include "/wamp/www/mtxserv/admin/ressources/code/bottom_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>
</body>

</html>