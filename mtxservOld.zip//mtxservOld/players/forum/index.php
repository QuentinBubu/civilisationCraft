<?php
header("Location: index_forum.php");