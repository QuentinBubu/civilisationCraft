<?php
session_start();
include "/wamp/www/mtxserv/admin/ressources/database/connexion_db.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

if (isset($_SESSION['account'])) {
    $requete = $db->prepare("SELECT * FROM forum_list WHERE id = :id");
    $requete->execute([
        "id" => $_GET['topic']
    ]);
    $resultsA = $requete->fetch();
    if (($resultsA['ecriture'] == 1 && $_SESSION['account'] != "Visiteur") || $_SESSION['account'] == "Administrateur") {
        if (isset($_POST['editor'])) {
            $requete = $db->prepare("INSERT INTO messages VALUES(:name_user, :send_date, :forum, :messages)");
            $requete->execute([
                "name_user" => $_SESSION['id'],
                "send_date" => date("Y-m-d H:i:s"),
                "forum" => $_GET['topic'],
                "messages" => $_POST['editor']
            ]);
            $requete = $db->prepare("INSERT INTO messages_copy VALUES(:name_user, :send_date, :forum, :messages)");
            $requete->execute([
                "name_user" => $_SESSION['id'],
                "send_date" => date("Y-m-d H:i:s"),
                "forum" => $_GET['topic'],
                "messages" => $_POST['editor']
            ]);
        }
    }
}

if (isset($_POST['admin-action']) && $_POST['admin-action'] != "defaut") {
    $requete = $db->prepare("UPDATE messages SET messages = '<i>Ce message a été supprimé par un administrateur!</i>' WHERE forum = :forum AND send_date = :send_date AND name_user = :name_user");
    $requete->execute([
        "forum" => $_GET['topic'],
        "send_date" => $_POST['send-date'],
        "name_user" => $_POST['send-user']
    ]);
    if($_POST['admin-action'] == "delet-avertissement"){
        $requete = $db->prepare("UPDATE users SET avertissements = avertissements +1 WHERE name_user = :name_user");
        $requete->execute([
            "name_user" => $_POST['send-user']
        ]);
    }
}

$requete = $db->query("SELECT name_site, description_site FROM configuration_site");
$results = $requete->fetch();
?>
<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <meta name="description" content="<?php echo $results['description_site']; ?>" />
    <link rel="shortcut icon" href="/admin/ressources/images/logo/logo.ico" />
    <link rel="stylesheet" href="/admin/ressources/style/style.css" type="text/css" />
    <script src="/ckeditor/ckeditor.js"></script>

    <title>Forum - <?php echo $results['name_site']; ?></title>
</head>

<body id="body_form_topic">
    <?php include "/wamp/www/mtxserv/admin/ressources/code/top_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
    ?>
    <div id="div_topic">
        <?php
        $requete = $db->prepare("SELECT * FROM forum_list WHERE id = :id");
        $requete->execute([
            "id" => $_GET['topic']
        ]);
        $resultsA = $requete->fetch();
        echo "<h1> " . $resultsA['nom'] . " </h1><h3>Par: " . $resultsA['createur'] . "</h3><hr />";
        $requete = $db->prepare("SELECT * FROM messages WHERE forum = :forum");
        $requete->execute([
            "forum" => $_GET['topic']
        ]);
        while ($results = $requete->fetch()) {
        ?>
            <div class="messages_div">
                <div class="div_topic_player">
                    <?php
                    $name = $results['name_user'];
                    $requete2 = $db->query("SELECT image_profil FROM users WHERE name_user = '$name' ");
                    $results2 = $requete2->fetch();
                    ?>
                    <img src="<?php echo $results2['image_profil']; ?>" alt="Photo du joueur" />
                    <?php echo $results['name_user']; ?>
                </div>
                <div class="div_topic_messages">
                    <?php echo $results['messages']; ?>
                </div>
                <div class="div_topic_date">
                    <?php
                    if (isset($_SESSION['account']) && $_SESSION['account'] == "Administrateur") {
                    ?>
                        <form action="" method="post">
                            <input type="text" name="send-date" hidden value="<?php echo $results['send_date'] ?>">
                            <input type="text" name="send-user" hidden value="<?php echo $results['name_user'] ?>">
                            <select name="admin-action">
                                <option value="defaut" selected disabled>Choisir une action</option>
                                <option value="delet">Supprimer</option>
                                <option value="delet-avertissement">Supprimer et mettre un avertissement</option>
                            </select>
                            <button type="submit">Valider</button>
                        </form>
                    <?php
                    }
                    echo $results['send_date']; ?>
                </div>
            </div>
            <br />
            <?php
        }
        if (isset($_SESSION['account'])) {
            if (($resultsA['ecriture'] == 1 && $_SESSION['account'] != "Visiteur") || $_SESSION['account'] == "Administrateur") {
            ?>
                <form method="POST" action="">
                    <textarea name="editor" id="editor" rows="10" cols="80"></textarea>
                    <input type="submit" value="Envoyer">
                    <script>
                        CKEDITOR.replace('editor', {
                            filebrowserUploadUrl: 'upload.php',
                        });
                    </script>
                </form>
        <?php
            }
        }
        ?>
    </div>
    <?php //include "/wamp/www/mtxserv/admin/ressources/code/bottom_bar.php"; 
    ?>
</body>

</html>