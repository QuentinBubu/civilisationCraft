<?php
session_start();
include "../admin/ressources/database/connexion_db.php";
include "../admin/ressources/code/functions.php";
$requete = $db->query("SELECT name_site, description_site FROM configuration_site");
$results = $requete->fetch();

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $mdp = $_POST['mdp'];
    $retour = connexion($id, $mdp, $db);
    if ($retour == "ok") {
        $_SESSION['id'] = $id;
        //verify avertissements
        $requete = $db->prepare("SELECT avertissements FROM users WHERE name_user = :id");
        $requete->execute([
            "id" => $_SESSION['id']
        ]);
        $results1 = $requete->fetch();
        $requete = $db->query("SELECT nombre_avertissement FROM configuration_site");
        $results2 = $requete->fetch();
        if($results1['avertissements'] >= $results2['nombre_avertissement']){
            $requete = $db->prepare("UPDATE users SET account_type = :account_type WHERE name_user = :id");
            $requete->execute([
                "account_type" => "Visiteur",
                "id" => $_SESSION['id']
            ]);
        }
        //redirection
        header("Location: ../index.php");
        exit();
    } elseif ($retour == "compte_introuvable") {
        $erreur = "compte_introuvable";
    } elseif ($retour == "mot_de_passe") {
        $erreur = "mot_de_passe";
    }
}

?>

<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <meta name="description" content="<?php echo $results['description_site']; ?>" />
    <link rel="shortcut icon" href="/admin/ressources/images/logo/logo.ico" />
    <link rel="stylesheet" href="/admin/ressources/style/style.css" type="text/css" />
    <title>Connexion - <?php echo $results['name_site']; ?></title>
</head>

<body id="body_connexion">
    <?php include "/wamp/www/mtxserv/admin/ressources/code/top_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>

    <div id="form_connexion">
        <form action="" method="POST">
            <table>
                <?php
                if (isset($erreur)) {
                ?>
                    <tr>
                        <td colspan="2" id="td_erreur">
                            <img src="/admin/ressources/images/other/error.png" alt="Erreur" />
                            <?php
                            if ($erreur == "compte_introuvable") {
                                echo "Erreur: Nous sommes désolés mais nous n'avons pas trouvé votre compte, il a peut-être été supprimé!";
                            } elseif ($erreur == "mot_de_passe") {
                                echo "Erreur: Le mot de passe saisis est incorect!";
                            }
                            unset($erreur);

                            ?>
                        </td>
                    </tr>

                <?php
                }
                ?>
                <tr>
                    <td class="td_left">
                        <label for="id">Votre identifiant: </label>
                    </td>
                    <td class="td_right">
                        <input type="text" name="id" placeholder="Votre identifiant ici" required />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <label for="mdp">Votre mot de passe</label>
                    </td>
                    <td class="td_right">
                        <input type="password" name="mdp" placeholder="Votre mot de passe ici" required />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <span style="font-style: italic;"><a href="">Mot de passe oublié?</a></span>
                    </td>
                    <td style="text-align: left;">
                        <input type="submit" value="Se connecter" />
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <?php include "/wamp/www/mtxserv/admin/ressources/code/bottom_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>

</body>

</html>