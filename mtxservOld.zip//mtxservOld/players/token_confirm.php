<?php
include "/wamp/www/mtxserv/admin/ressources/database/connexion_db.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$token = $_GET['token'];
if ($token[0] == "I") {
    $requete = $db->prepare("SELECT * FROM users WHERE token = :token");
    $requete->execute([
        "token" => $token
    ]);
    $results = $requete->fetch();
    $nb = $requete->rowCount();
    if ($nb == 1) {
        $requete = $db->prepare("UPDATE users SET token = :valid WHERE token = :token");
        $requete->execute([
            "valid" => "ok",
            "token" => $token
        ]);
?>
        <script type="text/javascript">
            if (confirm("Votre compte a bien été validé!")) {
                document.location.href = "../index.php";
            } else {
                document.location.href = "../index.php";
            }
        </script>
<?php
    }
}elseif($token[0] == "M"){
    $requete = $db->prepare("SELECT * FROM users WHERE new_token_mail = :token");
    $requete->execute([
        "token" => $token
    ]);
    $results = $requete->fetch();
    $nb = $requete->rowCount();
    if ($nb == 1) {
        $requete1 = $db->prepare("SELECT new_mail FROM users WHERE new_token_mail = :token");
        $requete1->execute([
            "token" => $token
        ]);
        $results = $requete1->fetch();
        $requete = $db->prepare("UPDATE users SET new_token_mail = 0, new_mail = 0, mail = :new_mail WHERE new_token_mail = :token");
        $requete->execute([
            "new_mail" => $results['new_mail'],
            "token" => $token
        ]);
?>
        <script type="text/javascript">
            if (confirm("Votre mail a bien été modifié!")) {
                document.location.href = "cpannel.php";
            } else {
                document.location.href = "cpannel.php";
            }
        </script>
<?php
}
}else{
    header("Location: ../index.php");
}
?>
