<?php
session_start();
ini_set('display_errors', 'on');
error_reporting(E_ALL);
include "../admin/ressources/database/connexion_db.php";
include "../admin/ressources/code/functions.php";
$requete = $db->query("SELECT name_site, description_site FROM configuration_site");
$results = $requete->fetch();

if (!empty($_GET['erreur'])) {
    $erreurV = $_GET['erreur'];
    if ($erreurV == "mdp") {
        $erreur = "Les mots de passes ne correspondent pas!";
    } elseif ($erreurV == "id") {
        $erreur = "L'identifiant saisis existe déjà!";
    } elseif ($erreurV == "mail") {
        $erreur = "L'e-mail saisis n'est pas valide!";
    } elseif ($erreurV == "mailex") {
        $erreur = "L'e-mail saisis est déjà répertoriée!";
    } elseif ($erreurV == "taille_id") {
        $erreur = "Saisissez un identifiant comportant entre 5 et 20 caractères!";
    } elseif ($erreurV == "taille_mdp") {
        $erreur = "Saisissez un mot de passe comportant entre 10 et 30 caractères!";
    }
    $erreurV = "";
    echo '<script type="text/javascript">' . 'alert("Erreur : ' . $erreur . '");' . '</script>';
}

if (isset($_POST['id'])) {
    $mdp = $_POST['mdp'];
    $mdp2 = $_POST['mdp2'];
    $mail = $_POST['mail'];
    $id = $_POST['id'];
    if (empty($_POST['newsletter'])) {
        $newsletter = 0;
    } else {
        $newsletter = 1;
    }
    $ip = getIp();
    if (empty($_POST['date_anniversaire'])) {
        $birthday = 0;
    } else {
        $birthday = $_POST['date_anniversaire'];
    }
    if (inscription_verif($mdp, $mdp2, $mail, $id, $db)) {
        $token = "I" . sha1(session_id() . microtime());
        $requete = $db->prepare("INSERT INTO users(id, name_user, pswd, mail, birthday, newsletter, token, account_type, IP, date_time, image_profil, new_mail, new_token_mail, avertissements) VALUES(0, :id, :mdp, :mail, :birthday, :newsletter,:token, :account_type, :ip, :date_time, :image_profil, 0, 0, 0)");
        $requete->execute(
            [
                "id" => $id,
                "mdp" => password_hash($mdp, PASSWORD_ARGON2ID),
                "mail" => $mail,
                "birthday" => $birthday,
                "newsletter" => $newsletter,
                "token" => $token,
                "account_type" => "Joueur",
                "ip" => $ip,
                "date_time" => date("Y-m-d H:i:s"),
                "image_profil" => "/admin/ressources/images/players/exemples/img_profil.png"
            ]
        );
        $_SESSION['id'] = $id;
        ?>
        <script type="text/javascript">
            if (confirm("Vous avez 10min pour valider votre mail!")) {
                document.location.href = "../index.php";
            } else {
                document.location.href = "../index.php";
            }
        </script>
<?php
    }
}

?>

<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <meta name="description" content="<?php echo $results['description_site']; ?>" />
    <link rel="shortcut icon" href="../admin/ressources/images/logo/logo.ico" />
    <link rel="stylesheet" href="../admin/ressources/style/style.css" type="text/css" />
    <title>Inscription - <?php echo $results['name_site']; ?></title>
</head>

<body id="body_inscription">
    <?php include "/wamp/www/mtxserv/admin/ressources/code/top_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>
    <div id="form_inscription">
        <form action="" method="POST">
            <table>
                <tr>
                    <td class="td_left">
                        <label for="id">* Votre identifiant: </label>
                    </td>
                    <td class="td_right">
                        <input type="text" name="id" placeholder="Votre identifiant ici" required />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <label for="mail">* Votre mail: </label>
                    </td>
                    <td class="td_right">
                        <input type="email" name="mail" placeholder="Votre mail ici" required />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <label for="mdp">* Votre mot de passe</label>
                    </td>
                    <td class="td_right">
                        <input type="password" name="mdp" placeholder="Votre mot de passe ici" required />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <label for="mdp2">* Confirmer votre mot de passe</label>
                    </td>
                    <td class="td_right">
                        <input type="password" name="mdp2" placeholder="Confirmer votre mot de passe" required />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <label for="date_anniversaire">Entrez votre date d'anniversaire</label>
                    </td>
                    <td class="td_right">
                        <input type="date" name="date_anniversaire" />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <label for="newsletter">Voulez-vous vous abonner à notre newsletter?</label>
                    </td>
                    <td class="td_right">
                        <input type="checkbox" name="newsletter" />
                    </td>
                </tr>
                <tr>
                    <td class="td_left">
                        <span style="font-style: italic;">* (Champs obligatoires)</span>
                    </td>
                    <td style="text-align: left;">
                        <input type="submit" value="S'inscrire" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <?php include "/wamp/www/mtxserv/admin/ressources/code/bottom_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ?>
</body>

</html>