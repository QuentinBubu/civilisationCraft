<?php
session_start();
include "/wamp/www/mtxserv/admin/ressources/database/connexion_db.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$requete = $db->prepare("DELETE FROM users WHERE name_user = :id");
$requete->execute([
    "id" => $_SESSION['id']
]);
session_unset();
session_destroy();
?>
<script>alert("Votre compte a bien été supprimé, cliquez sur \"Ok\"");</script>
<meta http-equiv="refresh" content="0; url=/index.php">