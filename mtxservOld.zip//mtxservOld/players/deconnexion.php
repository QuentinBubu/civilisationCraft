<?php
session_start();
session_unset();
session_destroy();
?>
<script>alert("Vous avez été déconnecter, cliquez sur \"Ok\"");</script>
<meta http-equiv="refresh" content="0; url=/index.php">