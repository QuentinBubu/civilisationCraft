<?php
$login = "root";
$pass = "";
try{
    $db = new PDO('mysql:host=localhost;dbname=mtxserv;charset=utf8', $login, $pass);
    $db -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    echo 'Exception reçue : ',  $e->getMessage(), "\n";
}
?>