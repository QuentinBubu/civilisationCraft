<header class="top_bar">
    <div class="img_top_bar"><a href="/index.php"><img src="/admin/ressources/images/logo/logo.ico" alt="Logo du serveur" id="logo_top_bar" /></a></div>
    <div class="others_top_bar">
        <span><a href="/players/player_list.php">Liste des joueurs</a></span>
        <span><a href="/players/forum/index_forum.php">Forum</a></span>
    </div>
    <div class="connexion_button">
        <?php
        if (!isset($_SESSION['id'])) { ?>
            <p>
                <a href="/players/connexion.php">Se connecter</a>
                <a href="/players/inscription.php">S'inscrire</a>
            </p>
        <?php
        } else {
            $requete = $db->prepare("SELECT image_profil FROM users WHERE name_user = :name_user");
            $requete->execute([
                "name_user" => $_SESSION['id']
            ]);
            $results = $requete->fetch();
        ?>
            <div class="profil_logo_div">
                <img src="<?php echo $results['image_profil']; ?>" alt="Image de profil" id="profil_top_bar" />
                <script>
                    var hauteur = document.getElementById("profil_top_bar").offsetHeight;
                    document.getElementById("profil_top_bar").style.width = hauteur + "px";
                </script>
                <div>
                    <a href="/players/cpannel.php">Paramètres</a>
                    <hr />
                    <a href="/players/deconnexion.php">Déconnexion</a>
                    <hr />
                </div>
            </div>

        <?php
        }
        ?>
    </div>
</header>