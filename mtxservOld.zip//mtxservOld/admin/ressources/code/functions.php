<?php
function inscription_verif($mdp, $mdp2, $mail, $id, $db)
{
    $page  = "/players/inscription.php";
    if ($mdp == $mdp2) {
        if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            if (strlen($id) < 5 || strlen($id) > 20) {
                $erreurV = "taille_id";
                $redirection = $page . "?erreur=" . $erreurV;
                header("Location: $redirection");
            } else {
                $requete = $db->query("SELECT * FROM users WHERE mail = '$mail'");
                if (($requete->rowCount() == 0)) {
                    if (strlen($mdp) < 10 || strlen($mdp) > 30) {
                        $erreurV = "taille_mdp";
                        $redirection = $page . "?erreur=" . $erreurV;
                        header("Location: $redirection");
                    } else {
                        $requete = $db->query("SELECT * FROM users WHERE name_user = '$id'");
                        if ($requete->rowCount() == 0) {
                            return true;
                        } else {
                            $erreurV = "id";
                            $redirection = $page . "?erreur=" . $erreurV;
                            header("Location: $redirection");
                        }
                    }
                } else {
                    $erreurV = "mailex";
                    $redirection = $page . "?erreur=" . $erreurV;
                    header("Location: $redirection");
                }
            }
        } else {
            $erreurV = "mail";
            $redirection = $page . "?erreur=" . $erreurV;
            header("Location: $redirection");
        }
    } else {
        $erreurV = "mdp";
        $redirection = $page . "?erreur=" . $erreurV;
        header("Location: $redirection");
    }
}

function update_account($categorie, $db, $old_mdp, $mdp, $mdp2, $mail, $id)
{
    $page = "/players/cpannel.php";
    if ($categorie == "password") {
        $requete = $db->prepare("SELECT pswd FROM users WHERE name_user = :id");
        $requete->execute([
            "id" => $id
        ]);
        $results = $requete->fetch();
        if (password_verify($old_mdp, $results['pswd'])) {
            if ($mdp == $mdp2) {
                if (strlen($mdp) >= 10 && strlen($mdp) <= 30) {
                    return "ok";
                } else {
                    $erreurV = "taille_mdp";
                    $redirection = $page . "?erreur=" . $erreurV;
                    //header("Location: $redirection");
                }
            } else {
                $erreurV = "mdp";
                $redirection = $page . "?erreur=" . $erreurV;
                header("Location: $redirection");
            }
        } else {
            $erreurV = "old_pswd";
            $redirection = $page . "?erreur=" . $erreurV;
            header("Location: $redirection");
        }
    } elseif ($categorie == "mail") {
        $requete = $db->prepare("SELECT pswd FROM users WHERE name_user = :id");
        $requete->execute([
            "id" => $id
        ]);
        $results = $requete->fetch();
        if (password_verify($mdp, $results['pswd'])) {
            if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                $requete = $db->query("SELECT * FROM users WHERE mail = '$mail'");
                if (($requete->rowCount() == 0)) {
                    return "ok";
                } else {
                    $erreurV = "mailex";
                    $redirection = $page . "?erreur=" . $erreurV;
                    header("Location: $redirection");
                }
            } else {
                $erreurV = "mail";
                $redirection = $page . "?erreur=" . $erreurV;
                header("Location: $redirection");
            }
        } else {
            $erreurV = "mdp_verify";
            $redirection = $page . "?erreur=" . $erreurV;
            header("Location: $redirection");
        }
    }
}

function getIp()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

function connexion($id, $mdp, $db)
{
    $requete = $db->prepare("SELECT name_user, pswd FROM users WHERE name_user = :id");
    $requete->execute([
        "id" => $id
    ]);
    if ($requete->rowCount() == 0) {
        return "compte_introuvable";
    } else {
        $results = $requete->fetch();
        if (password_verify($mdp, $results['pswd'])) {
            return "ok";
        } else {
            return "mot_de_passe";
        }
    }
}

function upload_image($dossier, $db, $nom)
{
    ini_set('upload_max_filesize', '11M');
    ini_set('post_max_size', '11M');
    $fichier = basename($_FILES['image']['name']);
    $taille_maxi = 100000000;
    $taille = filesize($_FILES['image']['tmp_name']);
    $extensions = array('.png', '.gif', '.jpg', '.jpeg', '.ico');
    $extension = strtolower(strrchr($_FILES['image']['name'], '.'));
    //Début des vérifications de sécurité...
    if (!in_array($extension, $extensions)) //Si l'extension n'est pas dans le tableau
    {
        $erreur = 'Erreur: Vous pouvez uploader un fichier de type png, gif, jpg, jpeg, ico';
        return $erreur;
    }
    if ($taille > $taille_maxi) {
        $erreur = 'Erreur: Le fichier est trop volumineux...';
        return $erreur;
    }
    if (!isset($erreur)) //S'il n'y a pas d'erreur, on upload
    {
        //On formate le nom du fichier ici...
        if ($nom == "") {
            $requete = $db->prepare("SELECT image_profil FROM users WHERE name_user = :id");
            $requete->execute([
                "id" => $_SESSION['id']
            ]);
            $results = $requete->fetch();
            if (substr($results['image_profil'], 0, 18) != "/admin/ressources/"){
                unlink(substr($results['image_profil'], 9));
            $fichier = "IMG" . sha1(session_id() . microtime()) . $extension;
            }
        } elseif ($nom == "logo") {
            unlink("/admin/ressources/images/logo/logo.ico");
            $fichier = $nom . $extension;
        } elseif ($nom == "RSA") {
            $fichier = "I" . $fichier;
        }
        if (move_uploaded_file($_FILES['image']['tmp_name'], $dossier . $fichier)) //Si la fonction renvoie TRUE, c'est que ça a fonctionné...
        {
            return $fichier;
        } else //Sinon (la fonction renvoie FALSE).
        {
            $erreur = "Erreur: Echec lors de l'upload";
            return $erreur;
        }
    } else {
        return "Erreur:" . $erreur;
    }
    /*
UPLOAD_ERR_NO_FILE : fichier manquant.
UPLOAD_ERR_INI_SIZE : fichier dépassant la taille maximale autorisée par PHP.
UPLOAD_ERR_FORM_SIZE : fichier dépassant la taille maximale autorisée par le formulaire.
UPLOAD_ERR_PARTIAL : fichier transféré partiellement.
*/
}

?>
