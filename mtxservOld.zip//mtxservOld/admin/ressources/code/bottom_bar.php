<footer class="bottom_bar">
    <?php 
    $requete = $db->query("SELECT name_site FROM configuration_site");
    $results = $requete->fetch();
     ?>
    <img src="/admin/ressources/images/logo/logo.ico" alt="Logo du serveur"/>
    <span>Tous droits réservés à <?php echo $results['name_site']; ?> | &copy; 2015-<?php echo date("Y"); ?> | <a href="/admin/ressources/code/mentions-legals.php">Mentions légals</a> </span>

</footer>