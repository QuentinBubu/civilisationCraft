<?php
session_start();
include "ressources/database/connexion_db.php";
include "ressources/code/functions.php";

if ($_SESSION['account'] != "Administrateur") {
    header("Location: ../index.php");
    exit();
}

if (isset($_POST['account_type'])) {
    $account_type = $_POST['account_type'];
    $nb_avertissement = $_POST['avertissement'];
    $id = $_POST['id'];
    if ($account_type == "suppr") {
        $requete = $db->query("DELETE FROM users WHERE id = $id");
    } else {
        $requete = $db->prepare("UPDATE users SET account_type = :account_type, avertissements = :avertissement WHERE id = $id");
        $requete->execute([
            "account_type" => $account_type,
            "avertissement" => $nb_avertissement
        ]);
    }
}

if (isset($_POST['input_icone'])) {
    $return = upload_image("D:/wamp/www/mtxserv/admin/ressources/images/logo/", $db, "logo"); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if ($return[0] == "l") {
?>
        <script type="text/javascript">
            if (confirm("Changement effectuer avec succès!")) {
                document.location.href = "cpannel_admin.php"
            } else {
                document.location.href = "cpannel_admin.php"
            }
        </script>
    <?php
    } else {
    ?>
        <script type="text/javascript">
            if (confirm("<?php echo $return; ?>")) {
                document.location.href = "cpannel_admin.php"
            } else {
                document.location.href = "cpannel_admin.php"
            }
        </script>
    <?php
    }
}

if (isset($_POST['input_rs'])) {
    $return = upload_image("D:/wamp/www/mtxserv/admin/ressources/images/logo/", $db, "RSA"); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if ($return[0] == "I") {
        $requete = $db->prepare("INSERT INTO reseaux_sociaux VALUE (:logo, :name_, :link)");
        $requete->execute([
            "logo" => $_POST['RSA_name'],
            "name_" => $_POST['RSA_link'],
            "link" => "/admin/ressources/images/logo/" . $return
        ]);
    ?>
        <script type="text/javascript">
            if (confirm("Mise en ligne effectuer avec succès!")) {
                document.location.href = "cpannel_admin.php"
            } else {
                document.location.href = "cpannel_admin.php"
            }
        </script>
    <?php
    } else {
    ?>
        <script type="text/javascript">
            if (confirm("<?php echo $return; ?>")) {
                document.location.href = "cpannel_admin.php"
            } else {
                document.location.href = "cpannel_admin.php"
            }
        </script>
    <?php
    }
}

if (isset($_GET['RSS'])) {
    $requete = $db->prepare("DELETE FROM reseaux_sociaux WHERE rs_name = :rs_name");
    $requete->execute([
        "rs_name" => $_GET['RSS']
    ]);
}

if (isset($_POST['name_of_site'])) {
    $requete = $db->prepare("UPDATE configuration_site SET description_site = :description_site, name_site = :name_site");
    $requete->execute([
        "description_site" => $_POST['textarea_config_description'],
        "name_site" => $_POST['name_of_site']
    ]);
}

if (isset($_GET['ACTU_DEL'])) {
    $requete = $db->prepare("DELETE FROM actus WHERE title = :title");
    $requete->execute([
        "title" => $_GET['ACTU_DEL']
    ]);
}

if (isset($_POST['actu_text'])) {
    $requete = $db->prepare("INSERT INTO actus VALUE (:actu_title, :actu_text, :actu_date)");
    $requete->execute([
        "actu_title" => $_POST['actu_title'],
        "actu_text" => nl2br($_POST['actu_text']),
        "actu_date" => date("Y-m-d H-i-s")
    ]);
    ?>
    <script type="text/javascript">
        if (confirm("Mise en ligne effectuer avec succès!")) {
            document.location.href = "cpannel_admin.php"
        } else {
            document.location.href = "cpannel_admin.php"
        }
    </script>
<?php
}

$requete = $db->query("SELECT name_site, description_site FROM configuration_site");
$results = $requete->fetch();
?>

<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <meta name="description" content="<?php echo $results['description_site']; ?>" />
    <link rel="shortcut icon" href="ressources/images/logo/logo.ico" />
    <link rel="stylesheet" href="ressources/style/style.css" type="text/css" />
    <title>Cpannel Administrateur - <?php echo $results['name_site']; ?></title>
    <script>
        var hauteur = document.getElementById("photo_profil_cpanneladmin").offsetHeight;
        document.getElementById("photo_profil_cpanneladmin").style.width = hauteur + "px";
        var hauteur = document.getElementById("photo_profil_cpanneladmin2").offsetHeight;
        document.getElementById("photo_profil_cpanneladmin2").style.width = hauteur + "px";
    </script>
</head>

<body id="body_inscription">
    <?php include "/wamp/www/mtxserv/admin/ressources/code/top_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
    ?>
    <div id="list_action_admin">
        <form action="" method="GET" id="seach_player_form_cpannel">
            <input type="search" name="search_player" placeholder="Rechercher un joueur" />
            <br />
            <input type="submit" value="Rechercher" />
        </form>
        <hr />
        <form action="" method="POST" enctype="multipart/form-data">
            <label>Mettre à jour l'icone du site: (format .ico demandé)</label>
            <input type="file" accept="image/*" name="image" />
            <label>(Image carré de préférence)</label>
            <input type="submit" value="Enregistrer" name="input_icone" />
        </form>
        <hr />
        <label><a href="cpannel_admin.php?modRS=1">Supprimer/Ajouter un réseau social</a></label>
        <hr />
        <label><a href="cpannel_admin.php?modND=0">Modifier le nom et la description du site</a></label>
        <hr />
        <label><a href="cpannel_admin.php?annonces=0">Supprimer/ajouter une annonce</a></label>
        <hr />
        <label><a href="cpannel_admin.php?msg=0">Voir les messages du forum</a></label>
        <hr />
    </div>
    <?php
    if (isset($_GET['msg']) && $_GET['msg'] == "0") {
    ?>
        <div id="message" style="transform: translate(25vw, -85vh);">
            <table>
                <thead>
                    <tr>
                        <td id="forum_id">Forum id</td>
                        <td id="sender-name">Nom d'utilisateur</td>
                        <td id="message">Message</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $requete = $db->query("SELECT * FROM messages_copy ORDER BY send_date DESC");
                    while ($results = $requete->fetch()) {
                    ?>
                        <tr>
                            <td><?php echo $results['forum']; ?></td>
                            <td><?php echo $results['name_user']; ?></td>
                            <td><?php echo $results['messages']; ?></td>
                        </tr>

                    <?php
                    }
                    ?>
                </tbody>

            </table>
        </div>
    <?php
    }
    if (isset($_GET['annonces']) && $_GET['annonces'] == "0") {
    ?>
        <div id="list_rs" style="transform: translate(25vw, -85vh);">
            <table>
                <thead>
                    <tr>
                        <td>Titre</td>
                        <td>Texte</td>
                        <td>Supprimer</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $requete = $db->query("SELECT * FROM actus");
                    while ($results = $requete->fetch()) {
                    ?>
                        <tr>
                            <td><?php echo $results['title']; ?></td>
                            <td><?php echo $results['text']; ?></td>
                            <td><a href="cpannel_admin.php?ACTU_DEL=<?php echo $results['title']; ?>">Supprimer</a></td>

                        </tr>

                    <?php
                    }
                    ?>
                    <tr>
                        <td colspan="4"><a href="cpannel_admin.php?ACTU=add">Ajouter une annonce</a></td>
                    </tr>
                </tbody>

            </table>
        </div>
    <?php
    }
    if (isset($_GET['ACTU']) && $_GET['ACTU'] == "add") {
    ?>
        <div id="div_maj_infos_site">
            <form action="" method="POST">
                <label for="actu_title">Titre de l'actu:</label>
                <input type="text" value="" name="actu_title" />
                <label for="actu_text">Contenu:</label>
                <textarea name="actu_text" rows="10"></textarea>
                <input type="submit" value="Enregistrer">
            </form>
        </div>
    <?php
    }

    if (isset($_GET['modND'])) {
        $requete = $db->query("SELECT * FROM configuration_site");
        $results = $requete->fetch();
    ?>
        <div id="div_maj_infos_site">
            <form action="" method="POST">
                <label for="name_of_site">Nom du site:</label>
                <input type="text" value="<?php echo $results['name_site']; ?>" name="name_of_site" />
                <label for="description_site">Description du site (250 caractères maximun recommandé)</label>
                <textarea name="textarea_config_description" rows="15" cols="60"><?php echo $results['description_site']; ?></textarea>
                <br />
                <input type="submit" value="Enregistrer">
            </form>
        </div>
    <?php
    }

    if (isset($_GET['modRS']) && $_GET['modRS'] == "1") {
    ?>
        <div id="list_rs" style="transform: translate(25vw, -85vh);">
            <table>
                <thead>
                    <tr>
                        <td id="logo_rs_cpannel">Logo</td>
                        <td id="nom_rs_cpannel">Nom</td>
                        <td id="lien_rs_cpannel">Lien</td>
                        <td id="modifier_rs_cpannel">Supprimer</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $requete = $db->query("SELECT * FROM reseaux_sociaux");
                    while ($results = $requete->fetch()) {
                    ?>
                        <tr>
                            <td><img src="<?php echo $results['link_image']; ?>" alt="Logo Reseau" id="Logo_rs" /></td>
                            <td><?php echo $results['rs_name']; ?></td>

                            <td><?php echo $results['link']; ?></td>
                            <td><a href="cpannel_admin.php?RSS=<?php echo $results['rs_name']; ?>">Supprimer</a></td>

                        </tr>

                    <?php
                    }
                    ?>
                    <tr>
                        <td colspan="4"><a href="cpannel_admin.php?RS=add">Ajouter un réseau social</a></td>
                    </tr>
                </tbody>

            </table>
        </div>
    <?php
    }
    if (isset($_GET['RS']) && $_GET['RS'] == "add") {
    ?>
        <div id="list_rs" style="transform: translate(25vw, -85vh);">
            <form action="" method="POST" enctype="multipart/form-data">
                <table>
                    <thead>
                        <tr>
                            <td id="logo_rs_cpannel">Logo</td>
                            <td id="nom_rs_cpannel">Nom</td>
                            <td id="lien_rs_cpannel">lien</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <input type="file" accept="image/*" name="image" />
                            </td>
                            <td>
                                <input type="text" placeholder="Nom du réseau" name="RSA_name" required />
                            </td>
                            <td>
                                <input type="text" name="RSA_link" placeholder="Lien du réseau" required />
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3"><input type="submit" value="Ajouter" name="input_rs" /></td>
                        </tr>
                    </tbody>

                </table>
            </form>
        </div>
    <?php
    }
    if (isset($_GET['search_player'])) {
    ?>
        <div id="player_list_div" style="transform: translate(25vw, -85vh);">
            <table>
                <thead>
                    <tr>
                        <td id="number_of_player">Id du joueur</td>
                        <td id="name_of_player">Nom du joueur</td>
                        <td id="role_of_player">Rôle du joueur</td>
                        <td id="inscription_date_of_player">Modifier</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!isset($_GET['search_player'])) {
                        $requete = $db->query("SELECT * FROM users");
                    } else {
                        $requete = $db->query('SELECT * FROM users WHERE name_user LIKE "%' . $_GET['search_player'] . '%"');
                    }
                    while ($results = $requete->fetch()) {
                    ?>
                        <tr>
                            <td><?php echo $results['id']; ?></td>
                            <td><img src="<?php echo $results['image_profil']; ?>" alt="Photo de profil" id="photo_profil_cpanneladmin" /><?php echo $results['name_user']; ?></td>
                            <td class="player_type_<?php echo $results['account_type']; ?>"><?php echo $results['account_type']; ?></td>
                            <td><a href="cpannel_admin.php?id=<?php echo $results['id']; ?>">Modifier</a></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>

            </table>
        </div>
    <?php
    }
    if (isset($_GET['id'])) {
    ?>
        <div id="div_cpannel_admin">
            <form action="" method="POST">
                <table>
                    <thead>
                        <tr>
                            <td id="number_of_playerP">Id du joueur</td>
                            <td id="name_of_playerP">Nom du joueur</td>
                            <td id="role_of_playerP">Rôle du joueur</td>
                            <td id="mail_of_playerP">Mail du joueur</td>
                            <td id="date_inscriptionP">Date d'inscription du joueur</td>
                            <td id="nombre_avertissementP">Nombre d'avertissement</td>
                            <td id="save">Enregistrer</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $requete = $db->prepare('SELECT * FROM users WHERE id = :id');
                        $requete->execute([
                            "id" => $_GET['id']
                        ]);
                        $results = $requete->fetch();
                        ?>
                        <tr>
                            <td><?php echo $results['id']; ?><input type="text" style="display: none" name="id" value="<?php echo $results['id']; ?>" /></td>
                            <td><img src="<?php echo $results['image_profil']; ?>" alt="Photo de profil" id="photo_profil_cpanneladmin2" /><?php echo $results['name_user']; ?></td>
                            <td><select name="account_type">
                                    <option value="Joueur" <?php if ($results['account_type'] == "Joueur") {
                                                                echo "selected";
                                                            } ?>>Joueur</option>
                                    <option value="Administrateur" <?php if ($results['account_type'] == "Administrateur") {
                                                                        echo "selected";
                                                                    } ?>>Administrateur</option>
                                    <option value="Visiteur" <?php if ($results['account_type'] == "Visiteur") {
                                                                    echo "selected";
                                                                } ?>>Visiteur</option>
                                    <option value="suppr">Supprimer le compte</option>
                                </select>
                            </td>
                            <td><?php echo $results['mail']; ?></td>
                            <td><?php echo $results['date_time']; ?></td>
                            <td><input type="number" name="avertissement" min="0" value="<?php echo $results['avertissements']; ?>"></td>
                            <td><input type="submit" value="Enregistrer" /></td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    <?php
    }
    include "/wamp/www/mtxserv/admin/ressources/code/bottom_bar.php"; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
    ?>
</body>

</html>